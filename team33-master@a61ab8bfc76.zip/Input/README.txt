To compile the button demo, I have provided a makefile for your convenience.
Simply use the following commands:
'make'
'./demo'

Please note that "demo" only demonstrates the Input class. The input class
will have an update function in the future when the Player class is implemented.
The input class will also be managed in the near future by the InputManager.
However, further discussion of the implementation must be had.

Please refer to the in-person demo given on November 1st at 2:30pm by
Alex Drazilov to fully understand the progress made. 

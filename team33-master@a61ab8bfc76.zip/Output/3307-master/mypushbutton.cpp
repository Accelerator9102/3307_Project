#include "mypushbutton.h"
#include <QPropertyAnimation>

MyPushButton::MyPushButton(QWidget *parent) : QPushButton(parent)
{
   this->setStyleSheet("background-color: rgb(0,255,255);"
                                          "border-style:solid;"
                                          "border-width:5px;"
                                          "border-color: #339;"
                                          "font-size: 30px;");
    this->resize(200,100);
}

MyPushButton::~MyPushButton(){

}

void MyPushButton::zoom1(){
    QPropertyAnimation * animation = new QPropertyAnimation(this,"geometry");

    animation->setDuration(200);

    animation->setStartValue(QRect(this->x(),this->y(),this->width(),this->height()));

    animation->setEndValue(QRect(this->x(),this->y()+10,this->width(),this->height()));

    animation->setEasingCurve(QEasingCurve::OutBounce);

    animation->start();
}

void MyPushButton::zoom2(){
    QPropertyAnimation * animation = new QPropertyAnimation(this,"geometry");

    animation->setDuration(200);

    animation->setStartValue(QRect(this->x(),this->y()+10,this->width(),this->height()));

    animation->setEndValue(QRect(this->x(),this->y(),this->width(),this->height()));

    animation->setEasingCurve(QEasingCurve::OutBounce);

    animation->start();
}

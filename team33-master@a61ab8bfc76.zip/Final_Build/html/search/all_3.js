var searchData=
[
  ['evaluatescores_12',['evaluateScores',['../classRound.html#a50fcc3927668e8f94f39f9d35c888b7d',1,'Round']]]
];

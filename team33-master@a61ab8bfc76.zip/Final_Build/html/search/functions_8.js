var searchData=
[
  ['removetimer_150',['removeTimer',['../classTimeManager.html#a115f8947014dbdac897f5a0414c7d624',1,'TimeManager']]],
  ['resetquestions_151',['resetQuestions',['../classQuestionManager.html#afa253b3fd1bbc34a9ce80446bb3a3b05',1,'QuestionManager']]],
  ['resetscore_152',['resetScore',['../classPlayer.html#a7dfdc0be35fa9ae42104a6bfe47634b8',1,'Player']]],
  ['resettoken_153',['resetToken',['../classAPIHelper.html#a8f91a57ea292230302b9011a5397e627',1,'APIHelper']]],
  ['restart_154',['restart',['../classGame.html#a0ed4071254b21c8a17c4faaa0c3c15f5',1,'Game']]],
  ['restarttimer_155',['restartTimer',['../classTimer.html#ac417566ec5d640216e8e63831df9a3ec',1,'Timer']]],
  ['round_156',['Round',['../classRound.html#a0f70575715420dfcc12ad3f3385d64e0',1,'Round']]]
];

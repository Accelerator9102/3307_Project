var searchData=
[
  ['round_201',['round',['../classPlayer.html#aafde2806156109484e41941ddf5f986d',1,'Player']]],
  ['round_5flength_202',['round_length',['../classGame.html#a8741a7b6ed8abe488ab62cb9e81da487',1,'Game']]],
  ['round_5fnumber_203',['round_number',['../classGame.html#aac9e4c1b25b4a42e912edb34558fd273',1,'Game']]]
];

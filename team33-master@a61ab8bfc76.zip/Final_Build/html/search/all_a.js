var searchData=
[
  ['pause_5fduration_49',['pause_duration',['../classTimer.html#a917863968853a83d1fc0db21c67f60c4',1,'Timer']]],
  ['player_50',['Player',['../classPlayer.html',1,'Player'],['../classInput.html#a10f2b9a48b531cc2b594ed935583805f',1,'Input::player()'],['../classPlayer.html#a5880374f2d6b0f940000082f56231a65',1,'Player::Player()']]],
  ['player_5fids_51',['player_IDs',['../classGame.html#a36da868b18e106205c256598a67574de',1,'Game']]],
  ['player_5fnumber_52',['player_number',['../classGame.html#aee681b7bae1721d3437c533d51a53498',1,'Game']]],
  ['players_53',['players',['../classGame.html#a7a383b13a08d4e72ea1e215cb1e8235b',1,'Game']]],
  ['point_5fvalue_54',['point_value',['../classGame.html#a7bdb3dc46ffd8d4eac4be752d10c895e',1,'Game::point_value()'],['../classRound.html#a949d5d811788904783fd83c7da1319fd',1,'Round::point_value()']]]
];

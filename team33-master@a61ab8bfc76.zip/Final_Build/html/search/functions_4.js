var searchData=
[
  ['input_139',['Input',['../classInput.html#abae3f379d3f157cf42dc857309832dba',1,'Input::Input()'],['../classInput.html#a116eed210953f9f772a4edc0b3e1cd85',1,'Input::Input(int ID, int buttonNumber, const Player *player)']]],
  ['inputmanager_140',['InputManager',['../classInputManager.html#a8be46886da639b26d67181c29dab6d6c',1,'InputManager']]],
  ['isanswerready_141',['isAnswerReady',['../classPlayer.html#a36377f7c75877503b780629f06e7c866',1,'Player']]],
  ['isgamedone_142',['isGameDone',['../classGame.html#ae19af2fb8a92c7464596bb394ada7e3d',1,'Game']]],
  ['isroundlive_143',['isRoundLive',['../classGame.html#a7413cf96f1ad002a818208c08e42808e',1,'Game']]],
  ['istimerdone_144',['isTimerDone',['../classTimer.html#a5254af83d7af0d20e068ec0fa43fc9cc',1,'Timer']]],
  ['istimeup_145',['isTimeUp',['../classRound.html#aa2dab6948daefeba17e94df33b2824bc',1,'Round']]]
];

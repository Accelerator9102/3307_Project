var searchData=
[
  ['question_55',['Question',['../classQuestion.html',1,'Question'],['../classQuestion.html#a076494e221eb2320441b9c95fab81caa',1,'Question::Question()'],['../classRound.html#ae0e687e005237b6620fd35b439399b00',1,'Round::question()']]],
  ['questionmanager_56',['QuestionManager',['../classQuestionManager.html',1,'QuestionManager'],['../classQuestionManager.html#a1ee79716772b9e8e47301ffb2a6f0675',1,'QuestionManager::QuestionManager()']]]
];

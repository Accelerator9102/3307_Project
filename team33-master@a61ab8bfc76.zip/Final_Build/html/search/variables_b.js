var searchData=
[
  ['score_204',['score',['../classPlayer.html#ace6abae8d66534ad0a1fd6458f786a6e',1,'Player']]],
  ['start_5ftime_205',['start_time',['../classTimer.html#ad79a5ebd6e6dd6324ce9f61ce6248613',1,'Timer']]],
  ['state_206',['state',['../classInput.html#a790d2f49c81e77cb4301c5bc40eefdd3',1,'Input']]],
  ['submitted_5fanswers_207',['submitted_answers',['../classRound.html#a741f96b091fc4f25de507896d1862eef',1,'Round']]]
];

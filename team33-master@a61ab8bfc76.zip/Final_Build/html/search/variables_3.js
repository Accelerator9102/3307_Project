var searchData=
[
  ['is_5fanswering_188',['is_answering',['../classPlayer.html#aec9663a78843b47251fab5c8dba45fec',1,'Player']]],
  ['is_5fpaused_189',['is_paused',['../classTimer.html#a111eaa692b89a12e4866b57b1831f51e',1,'Timer']]]
];

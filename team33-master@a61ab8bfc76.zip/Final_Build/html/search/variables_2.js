var searchData=
[
  ['correctanswer_184',['correctAnswer',['../classQuestion.html#a044c79130fa70b37b0f714cc45b8c62e',1,'Question']]],
  ['current_5fround_185',['current_round',['../classGame.html#a23aa29505ad8cac8790478208b4bb253',1,'Game']]],
  ['current_5ftime_186',['current_time',['../classTimer.html#a3d635904e26d40bc4148271e3f147ae7',1,'Timer']]],
  ['currentanswer_187',['currentAnswer',['../classPlayer.html#af6cb6c53b9e00297c60769d464d8afb8',1,'Player']]]
];

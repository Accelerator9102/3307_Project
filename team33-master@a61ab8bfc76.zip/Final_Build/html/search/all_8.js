var searchData=
[
  ['notify_46',['notify',['../classPlayer.html#aa2e3a4c6b2f456497fb656b83902fa7c',1,'Player']]],
  ['number_47',['number',['../classInput.html#a9086cae03fe1463cc7a99c24cdb36a3a',1,'Input']]]
];

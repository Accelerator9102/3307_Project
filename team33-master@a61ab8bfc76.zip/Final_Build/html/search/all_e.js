var searchData=
[
  ['time_5fbetween_5frounds_80',['time_between_rounds',['../classGame.html#a729b33226ef1c1a0ae19a7aae134c69b',1,'Game']]],
  ['time_5fbonus_81',['time_bonus',['../classGame.html#a201790d040b3280744b641daba2a07ed',1,'Game::time_bonus()'],['../classRound.html#a44fbbf9183f11585d3e555ad0cdc8ff5',1,'Round::time_bonus()']]],
  ['timemanager_82',['TimeManager',['../classTimeManager.html',1,'TimeManager'],['../classTimeManager.html#ab1c3cbb48ad68d928bb8b9a4ef210ed6',1,'TimeManager::TimeManager()']]],
  ['timer_83',['Timer',['../classTimer.html',1,'Timer'],['../classTimer.html#aa26b807838a117a3854099ac088a2b03',1,'Timer::Timer()'],['../classRound.html#a136754b8ec455e8cb61f823e8bf5e9e5',1,'Round::timer()']]],
  ['timers_84',['timers',['../classTimeManager.html#ab25146dbc080eddebc5aa32a7511eb81',1,'TimeManager']]],
  ['token_85',['token',['../classQuestionManager.html#a9be8ca514f494e2946af8758f31c917d',1,'QuestionManager']]],
  ['total_5frounds_86',['total_rounds',['../classGame.html#afbf31c5867bccf2539884a16b0ddfe6f',1,'Game']]]
];

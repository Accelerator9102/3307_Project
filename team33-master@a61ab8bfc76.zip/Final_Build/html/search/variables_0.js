var searchData=
[
  ['answerids_182',['answerIDs',['../classPlayer.html#a51a31796f7b121b33be5a63179a3e741',1,'Player']]]
];

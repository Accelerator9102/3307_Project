var searchData=
[
  ['removetimer_57',['removeTimer',['../classTimeManager.html#a115f8947014dbdac897f5a0414c7d624',1,'TimeManager']]],
  ['resetquestions_58',['resetQuestions',['../classQuestionManager.html#afa253b3fd1bbc34a9ce80446bb3a3b05',1,'QuestionManager']]],
  ['resetscore_59',['resetScore',['../classPlayer.html#a7dfdc0be35fa9ae42104a6bfe47634b8',1,'Player']]],
  ['resettoken_60',['resetToken',['../classAPIHelper.html#a8f91a57ea292230302b9011a5397e627',1,'APIHelper']]],
  ['restart_61',['restart',['../classGame.html#a0ed4071254b21c8a17c4faaa0c3c15f5',1,'Game']]],
  ['restarttimer_62',['restartTimer',['../classTimer.html#ac417566ec5d640216e8e63831df9a3ec',1,'Timer']]],
  ['round_63',['Round',['../classRound.html',1,'Round'],['../classPlayer.html#aafde2806156109484e41941ddf5f986d',1,'Player::round()'],['../classRound.html#a0f70575715420dfcc12ad3f3385d64e0',1,'Round::Round()']]],
  ['round_5flength_64',['round_length',['../classGame.html#a8741a7b6ed8abe488ab62cb9e81da487',1,'Game']]],
  ['round_5fnumber_65',['round_number',['../classGame.html#aac9e4c1b25b4a42e912edb34558fd273',1,'Game']]]
];

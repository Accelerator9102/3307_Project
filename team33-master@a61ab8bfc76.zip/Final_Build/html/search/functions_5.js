var searchData=
[
  ['notify_146',['notify',['../classPlayer.html#aa2e3a4c6b2f456497fb656b83902fa7c',1,'Player']]]
];

#include "TimeManager.h"

TimeManager* TimeManager::instance = NULL;

TimeManager::~TimeManager() {};

TimeManager& TimeManager::getInstance() {
    if (instance == NULL) {
        instance = new TimeManager();
    }
    return *instance;
}

const int TimeManager::addTimer(double stop_time = 0, bool start_now = false) {
    int this_key = key_count;
    Timer t(stop_time, start_now);
    timers.insert(std::pair<int, Timer>(this_key, t));
    //keys.push_back(this_key);
    key_count++;
    return this_key;
}

Timer& TimeManager::getTimer(const int& key) {
    return timers.at(key);
}

void TimeManager::removeTimer(const int& key) {
    timers.erase(key);
    //keys.erase(std::find(keys.begin(), keys.end(), key));
}

void TimeManager::update() {
    for (auto& timer : timers) {
        timer.second.update();
    }
}

TimeManager::TimeManager() {
    key_count = 0;
}

TimeManager::TimeManager(const TimeManager& other) { }

TimeManager& TimeManager::operator=(const TimeManager& other) { }

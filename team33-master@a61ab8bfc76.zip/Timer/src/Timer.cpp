#include "Timer.h"

Timer::Timer(double stop_time = 0, bool start_now = false) {
    this->stop_time = stop_time;
    pause_duration = std::chrono::seconds::zero();
    current_time = std::chrono::seconds::zero();
    start_time = std::chrono::steady_clock::now();
    last_pause_time = start_time;
    is_paused = !start_now;
}

const double Timer::getCurrentTime() const {
    return (double)(current_time - pause_duration).count();
}

const bool Timer::isTimerDone() const {
    return getCurrentTime() >= getStopTime();
}

const double Timer::getStopTime() const {
    return stop_time;
}

void Timer::setStopTime(const double& stop_time) {
    this->stop_time = stop_time;
}

void Timer::startTimer() {
    update();
    is_paused = false;
}

void Timer::stopTimer() {
    last_pause_time = std::chrono::steady_clock::now();
    is_paused = true;
}

void Timer::restartTimer() {
    std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();
    start_time = now;
    last_pause_time = now;
    pause_duration = std::chrono::seconds::zero();
    current_time = std::chrono::seconds::zero();
    is_paused = false;
}

void Timer::update() {
    std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();
    current_time = std::chrono::duration_cast<std::chrono::seconds>(now - start_time);
    if (is_paused)
        pause_duration = std::chrono::duration_cast<std::chrono::seconds>(now - last_pause_time);
}

Timer::~Timer() {}

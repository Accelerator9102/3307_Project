#ifndef TIMER_H
#define TIMER_H

#include <chrono>

class Timer {
    public:
        Timer(double stop_time, bool start_now);
        const double getCurrentTime() const;
        const bool isTimerDone() const;
        const double getStopTime() const;

        void setStopTime(const double& stop_time);

        void startTimer();
        void stopTimer();
        void restartTimer();
        void update();

        ~Timer();
    private:
        double stop_time;
        bool is_paused;
        std::chrono::steady_clock::time_point start_time, last_pause_time;
        std::chrono::seconds current_time, pause_duration;
};

#endif // TIMER_H

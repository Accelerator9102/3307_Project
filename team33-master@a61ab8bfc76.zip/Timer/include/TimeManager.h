#ifndef TIMEMANAGER_H
#define TIMEMANAGER_H

#include <Timer.h>
#include <map>
#include <vector>
#include <algorithm>

class TimeManager {
    public:
        virtual ~TimeManager();
        static TimeManager& getInstance();
        const int addTimer(double stop_time, bool start_now);
        Timer& getTimer(const int& key);
        void removeTimer(const int& key);
        void update();
    protected:
        TimeManager();
    private:
        TimeManager(const TimeManager& other);
        TimeManager& operator=(const TimeManager& other);
        static TimeManager* instance;

        std::map<int, Timer> timers;
        //std::vector<int> keys;
        int key_count;
};

#endif // TIMEMANAGER_H
